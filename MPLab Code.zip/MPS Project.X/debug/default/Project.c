#define F_CPU 8000000UL
#include <avr/io.h>
#include <avr/eeprom.h>
#include <util/delay.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>

#define ADC_SAMPLES 64
#define ADC_VREF 5.0f
#define ADC_RES 1024.0f
#define V_DIVIDER_RATIO 89.0f
#define ACS_SENSITIVITY 0.1f
#define ACS_ZERO_OFFSET 2.5f
#define V_MAX 225.0f
#define V_MIN 215.0f
#define I_MAX 20.0f

#define SRAM_V_BASE 0x0000
#define SRAM_I_BASE 0x0040

#define EEP_FAULT_COUNT 0x00
#define EEP_FAULT_BASE 0x02
#define EEP_RECORD_SIZE 6
#define EEP_MAX_RECORDS 50

#define FAULT_NONE 0
#define FAULT_OVV 1
#define FAULT_SAG 2
#define FAULT_OVC 3

#define LCD_RS_PIN PD0
#define LCD_EN_PIN PD1
#define LCD_D4_PIN PD2
#define LCD_D5_PIN PD3
#define LCD_D6_PIN PD4
#define LCD_D7_PIN PD5
#define LCD_PORT PORTD
#define LCD_DDR DDRD

#define RELAY_PIN PD6
#define RELAY_ON() (PORTD|=(1<<RELAY_PIN))
#define RELAY_OFF() (PORTD&=~(1<<RELAY_PIN))

#define LED_PIN PD7
#define LED_TOGGLE() (PORTD^=(1<<LED_PIN))

#define ALE_HIGH() (PORTB|=(1<<PB0))
#define ALE_LOW() (PORTB&=~(1<<PB0))
#define WE_HIGH() (PORTB|=(1<<PB1))
#define WE_LOW() (PORTB&=~(1<<PB1))
#define OE_HIGH() (PORTB|=(1<<PB2))
#define OE_LOW() (PORTB&=~(1<<PB2))
#define CS_SRAM_HIGH() (PORTB|=(1<<PB3))
#define CS_SRAM_LOW() (PORTB&=~(1<<PB3))

typedef struct{
uint8_t fault_type;
uint8_t vrms_h;
uint8_t vrms_l;
uint8_t irms_h;
uint8_t irms_l;
uint8_t event_num;
}FaultRecord;

volatile uint8_t g_fault_active=0;
volatile uint8_t g_fault_type=FAULT_NONE;
float g_vrms=0.0f;
float g_irms=0.0f;

void adc_init(void);
uint16_t adc_read(uint8_t channel);
void sram_init(void);
void sram_write(uint16_t addr,uint8_t data);
uint8_t sram_read(uint16_t addr);
void eeprom_write_fault(uint8_t type,float vrms,float irms);
void lcd_init(void);
void lcd_command(uint8_t cmd);
void lcd_data(uint8_t data);
void lcd_set_cursor(uint8_t row,uint8_t col);
void lcd_print(const char *str);
void lcd_clear(void);
float measure_vrms(void);
float measure_irms(void);
void handle_fault(uint8_t type);
void handle_normal(void);
void display_readings(float v,float i,uint8_t fault,uint8_t ftype);
void system_init(void);

void adc_init(void)
{
ADMUX=(1<<REFS0);
ADCSRA=(1<<ADEN)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
ADCSRA|=(1<<ADSC);
while(ADCSRA&(1<<ADSC));
}

uint16_t adc_read(uint8_t channel)
{
ADMUX=(ADMUX&0xF0)|(channel&0x07);
_delay_us(10);
ADCSRA|=(1<<ADSC);
while(ADCSRA&(1<<ADSC));
return ADC;
}

void sram_init(void)
{
DDRB|=(1<<PB0)|(1<<PB1)|(1<<PB2)|(1<<PB3);
DDRC|=0x1F;
WE_HIGH();
OE_HIGH();
CS_SRAM_HIGH();
ALE_LOW();
PORTC=0x00;
}

void sram_write(uint16_t addr,uint8_t data)
{
DDRA=0xFF;
OE_HIGH();
WE_HIGH();
CS_SRAM_LOW();

PORTA=(uint8_t)(addr&0x00FF);
ALE_HIGH();
_delay_us(1);

PORTC=(uint8_t)((addr>>8)&0x1F);
ALE_LOW();
_delay_us(1);

PORTA=data;

WE_LOW();
_delay_us(1);
WE_HIGH();

CS_SRAM_HIGH();
PORTC=0x00;
}

uint8_t sram_read(uint16_t addr)
{
uint8_t data;

DDRA=0xFF;
WE_HIGH();
OE_HIGH();
CS_SRAM_LOW();

PORTA=(uint8_t)(addr&0x00FF);
ALE_HIGH();
_delay_us(1);

PORTC=(uint8_t)((addr>>8)&0x1F);
ALE_LOW();
_delay_us(1);

DDRA=0x00;
PORTA=0xFF;

OE_LOW();
_delay_us(1);

data=PINA;

OE_HIGH();
CS_SRAM_HIGH();
PORTC=0x00;

return data;
}

void eeprom_write_fault(uint8_t type,float vrms,float irms)
{
FaultRecord rec;
uint8_t count=eeprom_read_byte((uint8_t*)EEP_FAULT_COUNT);
if(count==0xFF)
count=0;
uint8_t slot=count%EEP_MAX_RECORDS;
uint16_t v_int=(uint16_t)vrms;
uint16_t i_int=(uint16_t)(irms*10.0f);
rec.fault_type=type;
rec.vrms_h=(uint8_t)(v_int>>8);
rec.vrms_l=(uint8_t)(v_int&0xFF);
rec.irms_h=(uint8_t)(i_int>>8);
rec.irms_l=(uint8_t)(i_int&0xFF);
rec.event_num=count+1;
uint16_t addr=EEP_FAULT_BASE+(slot*EEP_RECORD_SIZE);
eeprom_write_block((const void*)&rec,(void*)(uintptr_t)addr,EEP_RECORD_SIZE);
count++;
eeprom_write_byte((uint8_t*)EEP_FAULT_COUNT,count);
}

static void lcd_pulse_en(void)
{
LCD_PORT|=(1<<LCD_EN_PIN);
_delay_us(1);
LCD_PORT&=~(1<<LCD_EN_PIN);
_delay_us(50);
}

static void lcd_write_nibble(uint8_t nibble)
{
LCD_PORT=(LCD_PORT&0xC3)|
((nibble&0x08)?(1<<LCD_D7_PIN):0)|
((nibble&0x04)?(1<<LCD_D6_PIN):0)|
((nibble&0x02)?(1<<LCD_D5_PIN):0)|
((nibble&0x01)?(1<<LCD_D4_PIN):0);

lcd_pulse_en();
}

void lcd_command(uint8_t cmd)
{
LCD_PORT&=~(1<<LCD_RS_PIN);

lcd_write_nibble(cmd>>4);
lcd_write_nibble(cmd&0x0F);

_delay_ms(2);
}

void lcd_data(uint8_t data)
{
LCD_PORT|=(1<<LCD_RS_PIN);

lcd_write_nibble(data>>4);
lcd_write_nibble(data&0x0F);

_delay_us(50);
}

void lcd_init(void)
{
LCD_DDR|=0xFF;
LCD_PORT=0x00;
_delay_ms(50);
LCD_PORT&=~(1<<LCD_RS_PIN);
lcd_write_nibble(0x03);
_delay_ms(5);
lcd_write_nibble(0x03);
_delay_ms(1);
lcd_write_nibble(0x03);
_delay_ms(1);
lcd_write_nibble(0x02);
_delay_ms(1);
lcd_command(0x28);
lcd_command(0x0C);
lcd_command(0x06);
lcd_command(0x01);
_delay_ms(2);
}

void lcd_clear(void)
{
lcd_command(0x01);
_delay_ms(2);
}

void lcd_set_cursor(uint8_t row,uint8_t col)
{
lcd_command(0x80+((row==0)?0x00:0x40)+col);
}

void lcd_print(const char *str)
{
while(*str)
lcd_data(*str++);
}

float measure_vrms(void)
{
uint16_t i;
uint8_t raw;
float sample,sum_sq=0.0f;

for(i=0;i<ADC_SAMPLES;i++)
{
uint16_t adc_val=adc_read(0);

float pin_v=((float)adc_val/ADC_RES)*ADC_VREF;
float line_v=pin_v*V_DIVIDER_RATIO;

uint8_t stored=(uint8_t)(line_v/2.0f);

sram_write(SRAM_V_BASE+i,stored);

_delay_us(312);
}

for(i=0;i<ADC_SAMPLES;i++)
{
raw=sram_read(SRAM_V_BASE+i);

sample=(float)raw*2.0f;

sum_sq+=sample*sample;
}

return sqrtf(sum_sq/(float)ADC_SAMPLES);
}

float measure_irms(void)
{
uint16_t i;
uint8_t raw;
float sample,sum_sq=0.0f;

for(i=0;i<ADC_SAMPLES;i++)
{
uint16_t adc_val=adc_read(1);

float pin_v=((float)adc_val/ADC_RES)*ADC_VREF;
float current=(pin_v-ACS_ZERO_OFFSET)/ACS_SENSITIVITY;

int8_t stored=(int8_t)(current*4.0f);

sram_write(SRAM_I_BASE+i,(uint8_t)stored);

_delay_us(312);
}

for(i=0;i<ADC_SAMPLES;i++)
{
raw=sram_read(SRAM_I_BASE+i);

sample=(float)((int8_t)raw)/4.0f;

sum_sq+=sample*sample;
}

return sqrtf(sum_sq/(float)ADC_SAMPLES);
}

void display_readings(float v,float i,uint8_t fault,uint8_t ftype)
{
char line1[17];
char line2[17];

uint16_t v_int=(uint16_t)v;
uint16_t v_dec=(uint16_t)((v-v_int)*10.0f);

uint16_t i_int=(uint16_t)i;
uint16_t i_dec=(uint16_t)((i-i_int)*10.0f);

snprintf(line1,sizeof(line1),"V:%d.%d I:%d.%d",v_int,v_dec,i_int,i_dec);

if(!fault)
{
snprintf(line2,sizeof(line2),"Status:NORMAL");
}
else
{
switch(ftype)
{
case FAULT_OVV:
snprintf(line2,sizeof(line2),"FAULT:OVERVOLT");
break;

case FAULT_SAG:
snprintf(line2,sizeof(line2),"FAULT:V SAG");
break;

case FAULT_OVC:
snprintf(line2,sizeof(line2),"FAULT:OVERCUR");
break;

default:
snprintf(line2,sizeof(line2),"FAULT");
break;
}
}

lcd_clear();

lcd_set_cursor(0,0);
lcd_print(line1);

lcd_set_cursor(1,0);
lcd_print(line2);
}

void handle_fault(uint8_t type)
{
RELAY_OFF();

eeprom_write_fault(type,g_vrms,g_irms);

g_fault_active=1;
g_fault_type=type;

display_readings(g_vrms,g_irms,1,type);
}

void handle_normal(void)
{
RELAY_ON();

g_fault_active=0;
g_fault_type=FAULT_NONE;

display_readings(g_vrms,g_irms,0,FAULT_NONE);
}

void system_init(void)
{
DDRD=0xFF;
PORTD=0x00;

DDRB=0x0F;
PORTB=0x0E;

DDRC=0x1F;
PORTC=0x00;

DDRA=0x00;
PORTA=0x00;

RELAY_OFF();

adc_init();
sram_init();
lcd_init();

lcd_clear();

lcd_set_cursor(0,0);
lcd_print("EV Safety Ctrl");

lcd_set_cursor(1,0);
lcd_print("Initializing");

_delay_ms(1500);

lcd_clear();

lcd_set_cursor(0,0);
lcd_print("System Ready");

_delay_ms(1000);

lcd_clear();

RELAY_ON();
}

int main(void)
{
uint16_t blink_counter=0;
system_init();
while(1)
{
g_vrms=measure_vrms();
g_irms=measure_irms();
if(g_vrms>V_MAX)
handle_fault(FAULT_OVV);
else if(g_vrms<V_MIN)
handle_fault(FAULT_SAG);
else if(g_irms>I_MAX)
handle_fault(FAULT_OVC);
else
handle_normal();
blink_counter++;
if(blink_counter>=25)
{
LED_TOGGLE();
blink_counter=0;
}
_delay_ms(10);
}
return 0;
}